# ETH Bet Front End 

# About
The betting system which allows 2 people to speculate on the price of an asset at a desired date.
